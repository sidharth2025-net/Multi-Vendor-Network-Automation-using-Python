from netmiko import ConnectHandler
from jinja2 import Environment, FileSystemLoader
import yaml
import logging

# Logging setup
logging.basicConfig(
    filename="../logs/results.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Load YAML inventory
with open("../inventory/devices.yml") as f:
    inventory = yaml.safe_load(f)

# Jinja2 environment
env = Environment(loader=FileSystemLoader("../templates"))

# Variables
vlan_data = {
    "vlan_id": 100,
    "vlan_name": "AUTOMATION_VLAN"
}

for device in inventory["devices"]:
    try:
        print(f"Connecting to {device['name']}")

        template_file = f"{device['vendor']}_vlan.j2"
        template = env.get_template(template_file)
        config = template.render(vlan_data)

        net_device = {
            "device_type": device["device_type"],
            "host": device["ip"],
            "username": device["username"],
            "password": device["password"]
        }

        connection = ConnectHandler(**net_device)
        output = connection.send_config_set(config.splitlines())
        connection.save_config()
        connection.disconnect()

        logging.info(f"{device['name']} - SUCCESS")
        print(f"{device['name']} configured successfully")

    except Exception as e:
        logging.error(f"{device['name']} - FAILED - {e}")
        print(f"Error configuring {device['name']}")