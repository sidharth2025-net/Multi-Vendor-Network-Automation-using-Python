# Multi Vendor Config Manager

Simple framework to render VLAN configs for Cisco, Juniper, and Arista devices.